def bro():
    print("eres mi bro pov")
def gg():
    print("bro que ez")
def shrek():
    print("que asco")
def fornite():
    print("toca pasto")
def brainrot():
    print("eres mi brainrot pov")
